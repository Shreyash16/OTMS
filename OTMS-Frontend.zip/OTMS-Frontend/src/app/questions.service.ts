import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Questions } from './questions'

@Injectable({
  providedIn: 'root'
})
export class QuestionsService {
  

  constructor(private http:HttpClient) { }
  
  public viewquestions():Observable<any>{
    console.log("Am inside service");
    return this.http.get("http://localhost:1111/viewquestions");
  }
  public addquestions(questions:Questions):Observable<any>{
    return this.http.post("http://localhost:1111/addquestions",questions,{responseType:'text'});
  }
  public deletequestions(questionsId:number):Observable<any>{
    console.log("inside delete service "+questionsId );
    return this.http.delete(`http://localhost:1111/deletequestions/${questionsId}`,{responseType:'text'});
  }
  public updatequestions(questions:Questions):Observable<any>{
    return this.http.put(`http://localhost:1111/updatequestions/${questions.questionsId}`,questions,{responseType:'text'});
  }
}
