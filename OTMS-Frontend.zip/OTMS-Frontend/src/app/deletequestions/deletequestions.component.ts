import { Component, OnInit } from '@angular/core';
import { Questions } from '../questions';
import { QuestionsService } from '../questions.service';
@Component({
  selector: 'app-deletequestions',
  templateUrl: './deletequestions.component.html',
  styleUrls: ['./deletequestions.component.css']
})
export class DeletequestionsComponent implements OnInit {

  questionsId:number = 0;
  msg:String;
  errorMsg:String;
  constructor(private questionsService:QuestionsService) { }

  ngOnInit(): void {
  }
  deleteQuestions(){
    console.log(this.questionsId);
    
    this.questionsService.deletequestions(this.questionsId).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.questionsId=null;},
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
      this.msg=undefined});
  }

}
