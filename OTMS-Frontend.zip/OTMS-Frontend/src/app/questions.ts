export class Questions {
        questionsId:number;
        questionsTitle:string;
        questionsOptions:string;
        questionsAnswer:number;
        questionsMarks:number;
        chosenAnswer:number;
        marksScored:number;
    }
    

